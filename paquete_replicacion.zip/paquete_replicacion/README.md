# Paquete de replicación: efecto de iniciar un diplomado docente sobre la nota y la aprobación

Trabajo final de ICS3564 Econometría Avanzada (PUC, segundo semestre de 2026). Gabriela Repetto y Josefina Pérez.
Replicación metodológica de Angrist y Lavy (2001, *Journal of Labor Economics* 19(2), 343–369), con datos administrativos de una institución de educación superior de la Región de Valparaíso y una extensión a diferencias en diferencias con inicio escalonado (Callaway y Sant'Anna, 2021).

## Advertencia: los datos de este paquete son simulados

La institución autorizó publicar solo resultados agregados y mostrar la estructura de las bases con datos simulados. Por eso:

- `datos/originales/` contiene **seis Excel simulados** con los mismos archivos, hojas y encabezados que las bases reales. No contienen ninguna fila, RUT ni código real de docentes o estudiantes.
- **Los resultados que produce este paquete no son los del informe.** Los del informe vienen de las bases reales.
- Los datos simulados traen un efecto verdadero del diplomado de **+0,25 puntos de nota** (parámetro `EFECTO_VERDADERO` en `simulacion/simular_datos.R`), puesto a propósito para comprobar que el método lo recupera. Con la semilla incluida, el ATT de nota de Callaway y Sant'Anna da 0,196 (EE 0,063, IC 93 % de 0,08 a 0,31). Queda bajo 0,25 porque promedia años de exposición parcial y completa.
- Una columna cambia de nombre respecto de la base real: la facultad de la asignatura en la carga docente se llama `ESCUELA_INST`, para no identificar a la institución. Con la base real hay que usar su nombre original (y el de `escuela_inst` en `R/07_emparejamiento.R`, módulo histórico que no se ejecuta).

## Requisitos

R 4.2 o superior con estos paquetes:

```r
install.packages(c("readxl", "writexl", "readr", "dplyr", "tidyr", "tibble", "purrr", "janitor",
                   "stringi", "scales", "yaml", "ggplot2", "did", "MatchIt", "cobalt", "fixest"))
```

## Cómo correrlo

1. Abrir R en la carpeta raíz del paquete (la que contiene `main.R`). En RStudio: abrir la carpeta como proyecto o fijarla con `setwd()`.
2. Ejecutar `source("main.R", encoding = "UTF-8")`, o desde la terminal `Rscript main.R`. Tarda unos 2 minutos.
3. Los resultados quedan en `salidas/` (CSV agregados) y `salidas/figuras/` (PDF y PNG). `datos/procesados/` guarda archivos intermedios.

Para regenerar los datos simulados: `Rscript simulacion/simular_datos.R` (semilla 20261124). En terminal conviene una sesión UTF-8 (`LANG=C.UTF-8`), porque los encabezados llevan tildes y Ñ.

Para usar las bases reales: reemplazar los seis Excel de `datos/originales/` (mismos nombres de archivo, o ajustar las rutas en `config/config.yml`) y poner en `analisis.nombre_programa` del config el nombre del diplomado tal como aparece en la base de perfeccionamiento.

## Configuración (`config/config.yml`)

Rutas de los archivos, período 2021 a 2026, regla de atribución de secciones (`unico`: solo secciones con un docente, la principal; `todos`: repartir, como robustez), mínimo de 5 estudiantes por sección, nivel de significancia de 7 % (IC 93 %, pedido por la institución), 999 réplicas bootstrap y semillas.

## Qué hace cada módulo (en el orden en que corre `main.R`)

| Orden | Script | Qué hace |
|---|---|---|
| 1 | `00_utilidades.R` | Funciones comunes: normalización de texto, llaves anonimizadas, estimación y agregación con `did`, exportación |
| 2 | `01_importar_limpiar.R` | Importa y limpia rendimiento, carga, perfeccionamiento e información docente. Quita la copia de 2025 en la hoja 2026, NRC inválidos, notas pendientes y posgrado |
| 3 | `02_construir_panel.R` | Agrega matrículas a sección y construye el panel docente y año, con resultados brutos y relativos al programa y período |
| 4 | `08_auditoria_cohortes.R` | Lee las postulaciones y define el tratamiento: año de la primera versión del diplomado efectivamente iniciada |
| 5 a 7 | `03_modelos.R`, `04_informe.R`, `05_analisis_anual_exploratorio.R` | Descriptivos del diseño anterior por certificación. Se mantienen por trazabilidad y no producen cifras del informe |
| 8 | `06_did_inicio_unificado.R` | DiD de Callaway y Sant'Anna con tres grupos de control |
| 9 | `09_auditoria_soporte_did.R` | Cuántos docentes sostienen cada celda y cada año del estudio de eventos |
| 10 | `07_matching_inicio_unificado.R` | Emparejamiento por cohorte (Mahalanobis, 3 controles, sin reemplazo) y DiD en la muestra emparejada |
| 11 | `10_robustez_temporal.R` | Corte en 2025 y efectos desde el año siguiente al inicio |
| 12 | `11_consolidacion_validacion.R` | Tabla comparativa de modelos y cohortes comunes |
| 13 | `12_validacion_identificacion.R` | Estudio de eventos con bandas simultáneas, pruebas de tendencias previas, sensibilidad sin la cohorte 2025 |
| 14 | `13_diagnostico_cierre.R` | Resultados absolutos y relativos con ambas reglas de atribución, tendencias previas por cohorte |
| 15 | `14_equivalencias_2026.R` | Audita la tabla de equivalencias de la modernización curricular 2026 (no produce cifras del informe) |
| 16 | `15_replicacion_angrist_lavy.R` | Réplica de la Tabla 1 de Angrist y Lavy, escala en DE, poder, asignación de cursos, 2WFE y figuras F2 a F4 |
| 17 | `16_complementos_informe.R` | Emparejamiento apilado, muestra del 2WFE, nota por régimen y figura F1 |

`06_did_anual.R` y `07_emparejamiento.R` son versiones anteriores del diseño y no se ejecutan. La Tabla 8 del anexo del informe indica de qué script y archivo sale cada tabla y figura.

## Privacidad

Todas las salidas de `salidas/` son agregadas. Los archivos con identificadores anonimizados quedan en `datos/procesados/` con el sufijo `_restringido` y no deben compartirse cuando se corre con las bases reales.
