# simular_datos.R
# Genera datos SIMULADOS con la misma estructura (archivos, hojas y encabezados) que las seis bases
# administrativas del proyecto. No usa ni copia ninguna fila real: todos los valores, códigos y
# nombres se inventan aquí. Sirve para que el código (main.R) corra de principio a fin en un
# computador que no tiene los datos reales.
#
# IMPORTANTE
#  * Los resultados que se obtienen con estos datos NO son los del informe. Los del informe
#    vienen de las bases reales de la institución, que no se pueden compartir.
#  * Los datos simulados incorporan un efecto verdadero del diplomado (EFECTO_VERDADERO, en puntos
#    de nota) para comprobar que el método lo recupera. En los datos reales no sabemos cuál es.
#  * Las magnitudes (docentes, secciones, tratados) son parecidas a las reales, no iguales.
#
# Uso (desde la carpeta raíz del proyecto):  Rscript simulacion/simular_datos.R
# Escribe en datos/originales/ (o en la carpeta de la variable de entorno DESTINO_SIM).
# Requiere el paquete writexl.

options(stringsAsFactors = FALSE)
if (!requireNamespace("writexl", quietly = TRUE)) stop("Instalar writexl: install.packages('writexl')")
SEMILLA <- 20261124L
set.seed(SEMILLA)
DESTINO <- Sys.getenv("DESTINO_SIM", "datos/originales")
dir.create(DESTINO, showWarnings = FALSE, recursive = TRUE)

# --- Parámetros del mundo simulado -------------------------------------------------------------
ANIOS <- 2021:2026
N_PROG <- 24                      # programas de pregrado simulados
N_CURSOS_PROG <- 10               # asignaturas por programa
N_DOCENTES <- 520                 # docentes con carga
EFECTO_VERDADERO <- 0.25          # efecto del diplomado sobre la nota (puntos, escala 1 a 7), desde el año siguiente al inicio
NOMBRE_PROGRAMA <- "DIPLOMADO SIMULADO EN DOCENCIA UNIVERSITARIA"   # debe coincidir con analisis.nombre_programa del config
# Versiones del diplomado (texto en el mismo formato que la base de postulantes)
VERSIONES <- c(v1 = "23 de octubre al 31 de mayo del 2024",
               v2 = "21 de octubre de 2024  al 24 de mayo de 2025",
               v3 = "10 de noviembre 2025 al 20 de junio de 2026",
               v4 = "08 de junio de 2026 al 17 de noviembre de 2026",
               v5 = "AUN NO INICIA")
INICIO_VERSION <- as.Date(c(v1 = "2023-10-23", v2 = "2024-10-21", v3 = "2025-11-10", v4 = "2026-06-08"))

letras <- function(n, k, prefijo = "") replicate(n, paste0(prefijo, paste(sample(LETTERS, k, TRUE), collapse = "")))
id_unicos <- function(n, k, prefijo) { x <- unique(letras(n * 2, k, prefijo)); x[seq_len(n)] }

# --- Programas y asignaturas -------------------------------------------------------------------
regimen <- sample(rep(c("S", "T"), times = c(14, 10)))
prog <- data.frame(
  id = seq_len(N_PROG), mat = paste0("SIM", LETTERS[seq_len(N_PROG)]),
  jornada = sample(1:2, N_PROG, TRUE), regimen = regimen,
  modalidad = sample(c("P", "B"), N_PROG, TRUE, prob = c(.8, .2)),
  num = sprintf("%04d", sample(100:999, N_PROG)), fac = sample(1:5, N_PROG, TRUE),
  base = rnorm(N_PROG, 5.1, .22))
prog$base <- prog$base + ifelse(prog$regimen == "T", 0.35, 0)            # los programas trimestrales ponen notas más altas
prog$cod <- paste0(prog$mat, prog$jornada, prog$regimen, prog$modalidad, prog$num)
prog$nombre <- paste("PROGRAMA SIMULADO", LETTERS[seq_len(N_PROG)])
prog$facultad <- paste("FACULTAD SIMULADA", prog$fac)
cursos <- do.call(rbind, lapply(prog$id, function(p) data.frame(
  prog = p, materia = prog$mat[p], curso = as.character(1000 + 10 * seq_len(N_CURSOS_PROG)),
  nombre = paste("ASIGNATURA SIMULADA", LETTERS[p], seq_len(N_CURSOS_PROG)))))
cursos$cod <- paste0(cursos$materia, cursos$curso)
# Modernización curricular 2026: una parte de los códigos cambia en 2026 (los mapea la tabla de equivalencias)
cursos$cod2026 <- ifelse(runif(nrow(cursos)) < .25, paste0(cursos$materia, as.integer(cursos$curso) + 5000L), cursos$cod)

# --- Docentes ----------------------------------------------------------------------------------
doc <- data.frame(id = id_unicos(N_DOCENTES, 7, "S"), stringsAsFactors = FALSE)
doc$dv <- sample(LETTERS, N_DOCENTES, TRUE)
doc$prog <- sample(prog$id, N_DOCENTES, TRUE)
doc$tipo <- sample(c("DH", "DO", "DI", "AC", "AD", "CO"), N_DOCENTES, TRUE, prob = c(.5, .15, .1, .1, .1, .05))
doc$alpha <- rnorm(N_DOCENTES, 0, .30)                                    # calidad docente latente, en puntos de nota
doc$peso <- rlnorm(N_DOCENTES, 0, .8)                                     # cuántas secciones suele dictar
doc$ini <- sample(2021:2025, N_DOCENTES, TRUE, prob = c(.45, .15, .15, .15, .10))
doc$fin <- ifelse(runif(N_DOCENTES) < .72, 2026L, pmin(2026L, doc$ini + sample(1:4, N_DOCENTES, TRUE)))

# --- Quiénes postulan y cuándo ------------------------------------------------------------------
# Postulantes: docentes con al menos 3 años de actividad y que empiezan en 2021-2022 (para tener años previos)
elegibles <- which(doc$ini <= 2022 & doc$fin >= 2025)
cert2023 <- sample(elegibles, 15)                                          # certificados 2023 de una versión que no está en la base de postulantes
resto <- setdiff(elegibles, cert2023)
post_idx <- sample(resto, 88)
asig_ver <- rep(c("v1", "v2", "v3", "v4", "v5"), times = c(31, 24, 15, 10, 8))
asig_ver <- asig_ver[seq_along(post_idx)]
post <- data.frame(idx = post_idx, ver = asig_ver)
# Algunas postulaciones repetidas (reingresos) y postulantes que no tienen carga en la base
extra <- rbind(
  data.frame(idx = post$idx[post$ver == "v1"][1:2], ver = "v3"),
  data.frame(idx = post$idx[post$ver == "v2"][1:3], ver = "v4"),
  data.frame(idx = post$idx[post$ver == "v2"][4], ver = "v2"),
  data.frame(idx = post$idx[post$ver == "v5"][1], ver = "v5"))
post <- rbind(post, extra)
sin_carga <- data.frame(id = id_unicos(10, 7, "T"), dv = sample(LETTERS, 10, TRUE), ver = sample(c("v1", "v2", "v3", "v4", "v5"), 10, TRUE))

# Inicio del tratamiento de cada docente = primera versión iniciada en la que postuló
orden <- c(v1 = 1, v2 = 2, v3 = 3, v4 = 4)
ini_trat <- rep(as.Date(NA), N_DOCENTES)
for (i in unique(post$idx)) {
  v <- post$ver[post$idx == i]; v <- v[v %in% names(INICIO_VERSION)]
  if (length(v)) ini_trat[i] <- min(INICIO_VERSION[v])
}
ini_trat[cert2023] <- as.Date("2023-05-22")                               # versión de mayo a noviembre de 2023
doc$inicio_trat <- ini_trat
doc$tratado <- !is.na(doc$inicio_trat)
doc$peso[doc$tratado] <- doc$peso[doc$tratado] * 2                         # los participantes dictan más secciones
doc$alpha[doc$tratado] <- doc$alpha[doc$tratado] - .15                     # los participantes parten algo más abajo (autoselección)

# Certificados: terminan algunos de cada versión (no todos los que inician)
cert <- rbind(
  data.frame(idx = cert2023, anio = 2023, mes = "NOVIEMBRE"),
  data.frame(idx = head(unique(post$idx[post$ver == "v1"]), 19), anio = 2024, mes = "JUNIO"),
  data.frame(idx = head(unique(post$idx[post$ver == "v2"]), 9), anio = 2025, mes = "JUNIO"),
  data.frame(idx = head(unique(post$idx[post$ver == "v3"]), 4), anio = 2026, mes = "JULIO"))
cert <- cert[!duplicated(cert$idx), ]

# --- Secciones -----------------------------------------------------------------------------------
cod_periodos <- list(S = c("10", "20"), T = c("05", "15", "25"))
tasa_secciones <- function(reg, anio) if (reg == "S") 1.4 else 0.9 + 0.22 * (anio - 2021)   # los programas trimestrales crecen con los años
tendencia <- c(`2021` = 0, `2022` = -.18, `2023` = -.12, `2024` = 0, `2025` = .20, `2026` = .42)
sec <- list(); nrc_sig <- list()
for (a in ANIOS) {
  for (p in prog$id) {
    for (cp in cod_periodos[[prog$regimen[p]]]) {
      cc <- cursos[cursos$prog == p & runif(N_CURSOS_PROG) < .9, ]
      if (!nrow(cc)) next
      n <- pmax(1L, rpois(nrow(cc), tasa_secciones(prog$regimen[p], a)))
      s <- cc[rep(seq_len(nrow(cc)), n), ]
      s$anio <- a; s$cp <- cp; s$periodo <- paste0(a, cp)
      sec[[length(sec) + 1L]] <- s
    }
  }
}
sec <- do.call(rbind, sec)
sec$nrc <- ave(seq_len(nrow(sec)), sec$periodo, FUN = seq_along) + 99L       # NRC único dentro de cada período
sec$periodo_nrc <- paste0(sec$periodo, sec$nrc)
sec$cod_usado <- ifelse(sec$anio == 2026, sec$cod2026, sec$cod)             # en 2026 algunos códigos cambian
sec$materia_u <- substr(sec$cod_usado, 1, 4); sec$curso_u <- substr(sec$cod_usado, 5, 8)
sec$seccion <- ave(seq_len(nrow(sec)), sec$periodo, sec$cod_usado, FUN = seq_along)
sec$metodo <- sample(c("P", "O", "OE", "B"), nrow(sec), TRUE, prob = c(.6, .2, .05, .15))
sec$sin_resultados <- runif(nrow(sec)) < .08                                # secciones de la carga sin notas en rendimiento

# --- Asignación de docentes a secciones ----------------------------------------------------------
asign <- vector("list", nrow(sec))
for (k in seq_len(nrow(sec))) {
  a <- sec$anio[k]
  act <- which(doc$ini <= a & doc$fin >= a)
  if (!length(act)) act <- seq_len(N_DOCENTES)
  mismo <- act[doc$prog[act] == sec$prog[k]]
  nd <- sample(1:4, 1, prob = c(.62, .25, .09, .04))
  pr <- doc$peso[act] * ifelse(act %in% mismo, 6, 1)
  elegidos <- act[sample.int(length(act), min(nd, length(act)), prob = pr)]
  asign[[k]] <- data.frame(k = k, d = elegidos)
}
asign <- do.call(rbind, asign)
asign$n_doc <- ave(asign$k, asign$k, FUN = length)

# --- Notas de cada sección ------------------------------------------------------------------------
# Exposición al diplomado: 0 antes del año de inicio, parcial en el año de inicio, completa después.
exposicion <- function(inicio, anio) {
  ai <- as.integer(format(inicio, "%Y")); mi <- as.integer(format(inicio, "%m"))
  ifelse(is.na(inicio) | anio < ai, 0, ifelse(anio == ai, ifelse(mi >= 9, 0.1, 0.5), 1))
}
asign$expo <- exposicion(doc$inicio_trat[asign$d], sec$anio[asign$k])
ai_d <- as.integer(format(doc$inicio_trat[asign$d], "%Y"))
asign$caida <- ifelse(!is.na(ai_d) & sec$anio[asign$k] == ai_d - 1L, -.12, 0)   # caída transitoria justo antes de postular
asign$efecto_d <- doc$alpha[asign$d] + EFECTO_VERDADERO * asign$expo + asign$caida
efecto_sec <- tapply(asign$efecto_d, asign$k, mean)
sec$mu <- prog$base[sec$prog] + tendencia[as.character(sec$anio)] +
  ifelse(prog$regimen[sec$prog] == "T", .10 * (sec$anio - 2021) / 5, 0) +
  efecto_sec[as.character(seq_len(nrow(sec)))] + rnorm(nrow(sec), 0, .25)
sec$n_est <- pmin(60L, pmax(1L, round(rlnorm(nrow(sec), 2.7, .7))))

# --- Carga docente (una fila por sección, docente y componente) ----------------------------------
A <- merge(asign, data.frame(k = seq_len(nrow(sec)), sec), by = "k")
A$lab <- runif(nrow(A)) < .25
carga <- rbind(cbind(A, tp = "TEO"), cbind(A[A$lab, ], tp = "LAB"))
carga$porc <- pmin(100, round(100 / carga$n_doc))
carga$campus <- sample(c("C1", "C2", "C3"), nrow(carga), TRUE)
carga_x <- data.frame(
  PERIODO_NRC = carga$periodo_nrc, PERIODO = carga$periodo, NRC = as.character(carga$nrc),
  MATERIA = carga$materia_u, CURSO = carga$curso_u, MATERIA_CURSO = paste0(carga$materia_u, carga$curso_u),
  ASIGNATURA = cursos$nombre[match(carga$cod, cursos$cod)], SECCION = as.character(carga$seccion),
  LIST_CRUZADA = NA_character_, CAMPUS = carga$campus, STATUS = "A", TP_HORARIO = carga$tp,
  METODO_EDUC = carga$metodo, MODO_CALIFIC = "V", SESION = "1", IDEN_ENLACE = NA_character_,
  CALIFICABLE = "Y", HR_CONTACTO = "64", TEORIA = "32", LABORATORIO = "32", OTRO = NA_character_,
  MAXIMA = "40", REAL_ = as.character(carga$n_est),
  RUT_DOC = paste0(doc$id[carga$d], doc$dv[carga$d]), `RUT SIN DV` = doc$id[carga$d], DV = doc$dv[carga$d],
  PORC_RESPON = as.character(carga$porc), CATEG = "OTR", TP_PERSONAL = doc$tipo[carga$d],
  RGL_CARGA_TRAB = doc$tipo[carga$d], CARGA_TRABAJO = "32", CARGA_TRAB_EFECTIVA = "32",
  ESCUELA_BANNER = prog$nombre[carga$prog], ESCUELA_INST = prog$facultad[carga$prog],
  check.names = FALSE)
# Algunas filas de períodos anuales (30, 35, 90) sin rendimiento: el código las descarta
anual <- carga_x[sample(nrow(carga_x), 150), ]
anual$PERIODO <- paste0(substr(anual$PERIODO, 1, 4), sample(c("30", "35", "90"), nrow(anual), TRUE))
anual$PERIODO_NRC <- paste0(anual$PERIODO, anual$NRC)
carga_x <- rbind(carga_x, anual)
writexl::write_xlsx(list(`PA_2021-2026` = carga_x), file.path(DESTINO, "Carga Docente 2021-2026 1.xlsx"))
message("Carga docente: ", nrow(carga_x), " filas")

# --- Rendimiento (una fila por estudiante y sección) ---------------------------------------------
pool_est <- id_unicos(14000, 8, "E")
S <- sec[!sec$sin_resultados, ]
rend <- do.call(rbind, lapply(seq_len(nrow(S)), function(i) {
  n <- S$n_est[i]
  nota <- pmin(7, pmax(1, round(rnorm(n, S$mu[i], 1.15), 1)))
  conc <- runif(n) < .004                                                  # algunas notas conceptuales (no numéricas)
  data.frame(PERIODO = S$periodo[i], RUT = sample(pool_est, n), NRC = as.character(S$nrc[i]),
    MATERIA = S$materia_u[i], CURSO = S$curso_u[i], MATERIA_CURSO = paste0(S$materia_u[i], S$curso_u[i]),
    TITULO = cursos$nombre[match(S$cod[i], cursos$cod)],
    NOTA = ifelse(conc, "NSP", as.character(nota * 10)), NOTA_CONV = ifelse(conc, "1", as.character(nota)),
    APRO_REPRO = ifelse(conc | nota < 4, "REPROBADO", "APROBADO"),
    FACULTAD = prog$facultad[S$prog[i]], COD_PROGRAMA = prog$cod[S$prog[i]], PROGRAMA = prog$nombre[S$prog[i]])
}))
hojas <- lapply(as.character(ANIOS), function(a) rend[substr(rend$PERIODO, 1, 4) == a, ])
names(hojas) <- as.character(ANIOS)
# La hoja 2026 repite los períodos 20 y 25 de 2025 (como en la base real); el código los descarta
hojas[["2026"]] <- rbind(rend[rend$PERIODO %in% c("202520", "202525"), ], hojas[["2026"]])
hojas[["2026"]]$FACULTAD <- NULL                                           # la hoja 2026 no trae FACULTAD
writexl::write_xlsx(hojas, file.path(DESTINO, "Base Rendimiento 2021-2026 1.xlsx"))
message("Rendimiento: ", nrow(rend), " filas")

# --- Perfeccionamiento ----------------------------------------------------------------------------
otros <- data.frame(idx = sample(N_DOCENTES, 600, TRUE), curso = sample(
  c("INDUCCION SIMULADA", "TALLER SIMULADO DE EVALUACION", "CURSO SIMULADO DE METODOLOGIAS", "SEMINARIO SIMULADO"), 600, TRUE),
  tray = sample(c("INICIAL", "HABILITANTE", "DISCIPLINAR"), 600, TRUE), anio = sample(2023:2026, 600, TRUE),
  mes = sample(c("ENERO", "MARZO", "JULIO", "DICIEMBRE"), 600, TRUE))
perf <- rbind(
  data.frame(idx = cert$idx, curso = NOMBRE_PROGRAMA, tray = "PROFESIONALIZANTE", anio = cert$anio, mes = cert$mes),
  otros)
perfeccionamiento <- data.frame(
  RUT_SIN_DIG = doc$id[perf$idx], DV = doc$dv[perf$idx], RUT = paste0(doc$id[perf$idx], doc$dv[perf$idx]),
  `NOMBRE PROGRAMA` = "PERFECCIONAMIENTO DOCENTE SIMULADO", `NOMBRE CURSO` = perf$curso,
  TRAYECTORIA = perf$tray, `AÑO` = as.character(perf$anio), MES = perf$mes,
  HORAS = ifelse(perf$tray == "PROFESIONALIZANTE", "176", "12"), check.names = FALSE)
tray_eq <- data.frame(`Nombre Curso` = c("Inducción simulada", "Taller simulado"), Trayectoria = c("INICIAL", "HABILITANTE"),
  `Año` = "2026", `Cantidad de horas` = c("12", "8"), `Aula Maestra` = c("SIM_2026A", "SIM_2026B"),
  `Equivalencia 1` = c("INDUCCIÓN SIMULADA", "TALLER SIMULADO"), `Equivalencia 2` = NA_character_,
  `Equivalencia 3` = NA_character_, `NOMBRE ACTUAL CERTIFICACIÓN` = c("INDUCCIÓN SIMULADA", "TALLER SIMULADO"), check.names = FALSE)
writexl::write_xlsx(list(Perfeccionamiento = perfeccionamiento, Trayectorias_Equivalencias = tray_eq),
  file.path(DESTINO, "Perfeccionamiento pedagógico docente consolidado 2026 2.xlsx"))

# --- Postulantes ----------------------------------------------------------------------------------
post_x <- rbind(
  data.frame(id = doc$id[post$idx], dv = doc$dv[post$idx], ver = post$ver),
  sin_carga)
postulantes <- data.frame(RUT = paste0(post_x$id, "-", post_x$dv), `RUT SIN DV` = post_x$id, DV = post_x$dv,
  fecha = unname(VERSIONES[post_x$ver]), check.names = FALSE)
writexl::write_xlsx(list(Postulantes = postulantes), file.path(DESTINO, "Postulantes Diplomado.xlsx"))

# --- Información del Docente (foto actual de los docentes vigentes) -------------------------------
vig <- which(doc$fin == 2026 & runif(N_DOCENTES) < .9)
nac <- as.integer(as.Date("1965-01-01") - as.Date("1899-12-30")) + sample(0:(20 * 365), length(vig), TRUE)
obt <- as.integer(as.Date("2005-01-01") - as.Date("1899-12-30")) + sample(0:(17 * 365), length(vig), TRUE)
info <- data.frame(`RUT SIN DV` = doc$id[vig], DV = doc$dv[vig], SEXO = sample(c("M", "H"), length(vig), TRUE),
  FECHA_NACIMIENTO = nac, NACIONALIDAD = "1", NIVEL_FORMACION_ACADEMICO = sample(c("1", "2", "3"), length(vig), TRUE),
  NOMBRE_TITULO_O_GRADO = "TITULO SIMULADO", NOMBRE_INSTITUCION_OBT_TITULO = "INSTITUCION SIMULADA",
  PAIS_OBTENCION_TIT_O_GRADO = "1", FECHA_OBT_TIT_O_GRADO = obt, PRINCIPAL_CARGO_ACADEMICO = "ACADEMICO",
  CARGO_NORMALIZADO = "9", NIVEL_SUPERIOR_ADSCRIPCION = prog$facultad[doc$prog[vig]],
  NIVEL_SECUNDARIO_ADSCRIPCION = "DEPARTAMENTO SIMULADO", COMUNA_MAYOR_FUNCION = "COMUNA SIMULADA",
  NOMBRE_PRINCIPAL_PROGRAMA = prog$nombre[doc$prog[vig]], TOTAL_HORAS_PRINCIPAL_PROGRAMA = sample(1000:6000, length(vig), TRUE),
  NUM_HORAS_PLANTA = sample(0:600, length(vig), TRUE), NUM_HORAS_CONTRATA = 0L, NUM_HORAS_HONORARIOS = 0L,
  JERARQUIA_ACADEMICA = sample(c("INSTRUCTOR", "ASISTENTE", "ASOCIADO"), length(vig), TRUE),
  JERARQUIA_ACADEMICA_OCDE = sample(1:3, length(vig), TRUE), VIGENCIA = 1L, check.names = FALSE)
writexl::write_xlsx(list(Hoja2 = info), file.path(DESTINO, "Información del Docente.xlsx"))

# --- Equivalencias 2026 -----------------------------------------------------------------------------
eq <- cursos[cursos$cod2026 != cursos$cod, ]
eq_x <- data.frame(FACULTAD = paste0("F", prog$fac[eq$prog]), `Código Carrera / Programa` = prog$cod[eq$prog],
  `ASIGNATURA\nPLAN MODERNIZADO 2026` = eq$nombre, `MATERIA-CURSO 2026` = eq$cod2026, `MATERIA-CURSO_2025` = eq$cod,
  `ASIGNATURA(S)\nPLAN VIGENTE` = eq$nombre, CRITICA_2026 = sample(c("0", "1"), nrow(eq), TRUE, prob = c(.8, .2)),
  check.names = FALSE)
writexl::write_xlsx(list(Hoja1 = eq_x), file.path(DESTINO, "Equivalencias 2026.xlsx"))

message("Listo. Archivos simulados en ", DESTINO, " (semilla ", SEMILLA, "). Efecto verdadero simulado: ", EFECTO_VERDADERO, " puntos de nota.")
